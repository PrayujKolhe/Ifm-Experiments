In this project I interfaced the Static Inclination sensor JN2100(ifm) with the ecomat controller CR710s and visualized values by using Graph traces.
The Use cases of this sensor can be : a) Adjusting the Gun of the tank to appropriate angle.
                                      b) In the submarines and Bottle-filling plants.
